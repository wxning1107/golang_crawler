package main

import (
	"fmt"
	"github.com/ggaaooppeenngg/TEST"
)

func main() {
	fmt.Println(TEST.TEST)
}
